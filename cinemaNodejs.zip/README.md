# MNB CINEMA

## How to lunch the app

- Backend :
  - cd backend 
  - npm install 
  - nodemon start  
  
- frontend (Angular cli 8 is needed !) :
  - cd frontend 
  - npm install
  - ng serve --port 8080 

