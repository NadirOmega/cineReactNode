import { Cinema } from '../cinema/cinema';

export class Theater {
    _id?: String;
    name?: String;
    num_places?: Number;
    cinema?: Cinema;
}
