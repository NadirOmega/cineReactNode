import { Theater } from './theater';

describe('Theater', () => {
  it('should create an instance', () => {
    expect(new Theater()).toBeTruthy();
  });
});
