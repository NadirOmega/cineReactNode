import { App } from './app';

describe('App', () => {
  it('should create an instance', () => {
    expect(new App()).toBeTruthy();
  });
});
