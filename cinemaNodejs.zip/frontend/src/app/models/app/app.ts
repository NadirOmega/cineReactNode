export class App {
    email?: string;
    username?: string;
    status?: string;
    error?: boolean;
    role?: string;
}