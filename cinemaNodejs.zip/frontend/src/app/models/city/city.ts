export class City {
    _id?: String;
    name?: String;
}
