export class User {
    id?: String;
    username?: String;
    email?: String;
    password?: String;
    active?: String;
    firstname?: String;
    lastname?: String;
}
