import { City } from '../city/city';

export class Cinema {
    _id?: String;
    name?: String;
    description?: String;
    address?: String;
    longitude?: String;
    latitude?: String;
    city?: City;
}
