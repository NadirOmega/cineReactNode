export const environment = {
  production: true,
  API_URL: 'http://34.89.172.120:8080'
};
